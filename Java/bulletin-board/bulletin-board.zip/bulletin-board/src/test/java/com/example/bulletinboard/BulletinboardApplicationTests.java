package com.example.bulletinboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulletinboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
